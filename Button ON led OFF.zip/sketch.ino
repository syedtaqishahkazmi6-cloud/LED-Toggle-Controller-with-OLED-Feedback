#include <Wire.h>
#include <Adafruit_GFX.h>
#include <Adafruit_SSD1306.h>

// Pin Definitions
#define Green_Led 4
#define Red_Led 10
#define Yellow_Led 2
#define Button_Green 6
#define Button_Red 9
#define Button_Yellow 7

// OLED Definitions
#define SCREEN_WIDTH 128
#define SCREEN_HEIGHT 64
Adafruit_SSD1306 display(SCREEN_WIDTH, SCREEN_HEIGHT, &Wire, -1);

// LED states (ON by default)
bool greenState = true;
bool redState = true;
bool yellowState = true;

void setup() {
  pinMode(Green_Led, OUTPUT);
  pinMode(Red_Led, OUTPUT);
  pinMode(Yellow_Led, OUTPUT);
  
  // FIXED: Changed to INPUT_PULLUP for standard Arduino compatibility
  // Buttons should connect the pin to GND when pressed
  pinMode(Button_Green, INPUT_PULLUP);
  pinMode(Button_Red, INPUT_PULLUP);
  pinMode(Button_Yellow, INPUT_PULLUP);

  if (!display.begin(SSD1306_SWITCHCAPVCC, 0x3C)) {
    for (;;); 
  }
  
  display.clearDisplay();
  display.setTextColor(WHITE);
  display.setTextSize(1);
  display.setCursor(20, 25);
  display.print("PULLUP INITIALIZED");
  display.display();
  delay(1500);
}

void loop() {
  // Logic: With INPUT_PULLUP, the pin is HIGH when released and LOW when pressed.
  // We want the LED to be OFF when pressed (LOW).
  
  // Green Logic
  if (digitalRead(Button_Green) == LOW) {
    greenState = false; // Button pressed (connected to GND) -> OFF
  } else {
    greenState = true;  // Released (Pulled to 5V) -> ON
  }

  // Red Logic
  if (digitalRead(Button_Red) == LOW) {
    redState = false;
  } else {
    redState = true;
  }

  // Yellow Logic
  if (digitalRead(Button_Yellow) == LOW) {
    yellowState = false;
  } else {
    yellowState = true;
  }

  // Apply states to LEDs
  digitalWrite(Green_Led, greenState);
  digitalWrite(Red_Led, redState);
  digitalWrite(Yellow_Led, yellowState);

  // Update Display
  display.clearDisplay();
  display.setTextSize(1);
  display.setCursor(0, 0);
  display.print("System Status:");
  display.setCursor(0, 20);

  display.print("Green:  "); display.println(greenState ? "ON" : "OFF");
  display.print("Red:    "); display.println(redState ? "ON" : "OFF");
  display.print("Yellow: "); display.println(yellowState ? "ON" : "OFF");
  
  display.display();
}